"use client"

import { useState } from "react"
import CircleHoverAnimation from "@/components/circle-hover-animation"
import Toolbar from "@/components/toolbar"

export default function Home() {
  const [glowColor, setGlowColor] = useState("74,222,128") // Default green RGB
  const [messages, setMessages] = useState({
    right: "Right tooltip",
    left: "Left tooltip",
    top: "Top tooltip",
    bottom: "Bottom tooltip",
  })

  const handleMessageChange = (direction: string, message: string) => {
    setMessages((prev) => ({
      ...prev,
      [direction]: message,
    }))
  }

  return (
    <main className="flex min-h-screen flex-col items-center justify-center bg-[#121212] p-24 pb-32">
      <div className="grid grid-cols-2 gap-x-80 gap-y-40">
        <div className="flex flex-col items-center">
          <CircleHoverAnimation direction="right" message={messages.right} glowColor={glowColor} />
        </div>

        <div className="flex flex-col items-center">
          <CircleHoverAnimation direction="left" message={messages.left} glowColor={glowColor} />
        </div>

        <div className="flex flex-col items-center">
          <CircleHoverAnimation direction="top" message={messages.top} glowColor={glowColor} />
        </div>

        <div className="flex flex-col items-center">
          <CircleHoverAnimation direction="bottom" message={messages.bottom} glowColor={glowColor} />
        </div>
      </div>

      <Toolbar onColorChange={setGlowColor} onMessageChange={handleMessageChange} messages={messages} />
    </main>
  )
}
