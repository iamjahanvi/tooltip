"use client"

import type React from "react"
import { useState, useRef, useEffect } from "react"

interface ToolbarProps {
  onColorChange: (color: string) => void
  onMessageChange: (direction: string, message: string) => void
  messages: Record<string, string>
}

export default function Toolbar({ onColorChange, onMessageChange, messages }: ToolbarProps) {
  const [colorInput, setColorInput] = useState("#4ADE80") // Default green color
  const [activeTab, setActiveTab] = useState<string | null>("color") // 'color', 'text', or null
  const [selectedDirection, setSelectedDirection] = useState("right")
  const [isExpanded, setIsExpanded] = useState(false)
  const toolbarRef = useRef<HTMLDivElement>(null)

  // Convert hex to RGB for the component
  const handleColorChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const hexColor = e.target.value
    setColorInput(hexColor)

    // Convert hex to RGB
    const r = Number.parseInt(hexColor.slice(1, 3), 16)
    const g = Number.parseInt(hexColor.slice(3, 5), 16)
    const b = Number.parseInt(hexColor.slice(5, 7), 16)

    onColorChange(`${r},${g},${b}`)
  }

  // Handle tab click
  const handleTabClick = (tab: string) => {
    setActiveTab(activeTab === tab ? null : tab)
  }

  // Handle click outside to close toolbar
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (toolbarRef.current && !toolbarRef.current.contains(event.target as Node)) {
        setIsExpanded(false)
      }
    }

    // Only add the event listener when the toolbar is expanded
    if (isExpanded) {
      document.addEventListener("mousedown", handleClickOutside)
    }

    return () => {
      document.removeEventListener("mousedown", handleClickOutside)
    }
  }, [isExpanded])

  return (
    <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-50" ref={toolbarRef}>
      <div
        className={`bg-[#1E1E1E]/90 backdrop-blur-lg rounded-xl border border-white/10 shadow-xl overflow-hidden transition-all duration-400 ${
          isExpanded ? "w-[450px]" : "w-[120px]"
        }`}
        style={{
          transitionTimingFunction: "cubic-bezier(0.4, 0.0, 0.2, 1)", // Smooth easing without bounce
        }}
      >
        {isExpanded ? (
          <>
            {/* Toolbar tabs - centered */}
            <div className="flex justify-center border-b border-white/10">
              <button
                className={`px-6 py-2 text-sm font-medium transition-colors ${
                  activeTab === "color" ? "text-white bg-white/10" : "text-white/60 hover:text-white/80"
                }`}
                onClick={() => handleTabClick("color")}
              >
                Color
              </button>
              <button
                className={`px-6 py-2 text-sm font-medium transition-colors ${
                  activeTab === "text" ? "text-white bg-white/10" : "text-white/60 hover:text-white/80"
                }`}
                onClick={() => handleTabClick("text")}
              >
                Text
              </button>
            </div>

            {/* Fixed height content container */}
            <div className="h-[60px] relative">
              {/* Color tab content */}
              <div
                className={`absolute inset-0 p-4 flex items-center justify-center transition-opacity duration-300 ${
                  activeTab === "color" ? "opacity-100 z-10" : "opacity-0 z-0"
                }`}
              >
                <div className="flex items-center gap-4 justify-center">
                  <div className="flex items-center gap-3">
                    <div className="relative">
                      <input
                        type="color"
                        value={colorInput}
                        onChange={handleColorChange}
                        className="absolute inset-0 opacity-0 w-full h-full cursor-pointer"
                      />
                      <div
                        className="w-8 h-8 rounded-md border border-white/20"
                        style={{ backgroundColor: colorInput }}
                      ></div>
                    </div>
                    <span className="text-white/80 text-sm font-mono">{colorInput}</span>
                  </div>

                  {/* Quick color presets */}
                  <div className="flex items-center gap-2 ml-4">
                    {["#4ADE80", "#3B82F6", "#EC4899", "#F59E0B", "#8B5CF6"].map((color) => (
                      <button
                        key={color}
                        className="w-6 h-6 rounded-full border border-white/20 transition-transform hover:scale-110"
                        style={{ backgroundColor: color }}
                        onClick={() => {
                          setColorInput(color)
                          // Convert hex to RGB
                          const r = Number.parseInt(color.slice(1, 3), 16)
                          const g = Number.parseInt(color.slice(3, 5), 16)
                          const b = Number.parseInt(color.slice(5, 7), 16)
                          onColorChange(`${r},${g},${b}`)
                        }}
                      ></button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Text tab content */}
              <div
                className={`absolute inset-0 p-4 flex items-center justify-center transition-opacity duration-300 ${
                  activeTab === "text" ? "opacity-100 z-10" : "opacity-0 z-0"
                }`}
              >
                <div className="flex items-center gap-4 justify-center w-full px-4">
                  <div className="w-1/3">
                    <select
                      value={selectedDirection}
                      onChange={(e) => setSelectedDirection(e.target.value)}
                      className="bg-[#2A2A2A] border border-white/10 rounded-md px-3 pr-8 py-1.5 text-white text-sm w-full focus:outline-none focus:ring-1 focus:ring-white/30"
                    >
                      <option value="right">Right</option>
                      <option value="left">Left</option>
                      <option value="top">Top</option>
                      <option value="bottom">Bottom</option>
                    </select>
                  </div>
                  <div className="w-2/3">
                    <input
                      type="text"
                      value={messages[selectedDirection]}
                      onChange={(e) => onMessageChange(selectedDirection, e.target.value)}
                      className="bg-[#2A2A2A] border border-white/10 rounded-md px-3 py-1.5 text-white text-sm w-full focus:outline-none focus:ring-1 focus:ring-white/30"
                      placeholder="Enter tooltip text..."
                    />
                  </div>
                </div>
              </div>
            </div>
          </>
        ) : (
          // Customize button (without icon)
          <button
            className="w-full h-10 px-4 text-white/90 text-sm font-medium hover:bg-white/5 transition-colors flex items-center justify-center"
            onClick={() => setIsExpanded(true)}
          >
            Customize
          </button>
        )}
      </div>
    </div>
  )
}
