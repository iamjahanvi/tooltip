"use client"

import { useState, useEffect, useRef } from "react"

type Direction = "right" | "left" | "top" | "bottom"

interface CircleHoverAnimationProps {
  direction?: Direction
  message?: string
  glowColor?: string
}

export default function CircleHoverAnimation({
  direction = "right",
  message = "Hover message",
  glowColor = "74,222,128", // Default green RGB values
}: CircleHoverAnimationProps) {
  const [isHovered, setIsHovered] = useState(false)
  const [displayText, setDisplayText] = useState("")
  const [isAnimating, setIsAnimating] = useState(false)
  const animationTimeoutRef = useRef<NodeJS.Timeout | null>(null)

  // Text scramble animation effect
  useEffect(() => {
    // Clean up any existing animation
    if (animationTimeoutRef.current) {
      clearTimeout(animationTimeoutRef.current)
    }

    if (isHovered) {
      // Start with random characters
      const startScramble = () => {
        setIsAnimating(true)
        let iteration = 0
        const maxIterations = 10
        const finalText = message

        // Characters to use for scrambling
        const chars = "!<>-_\\/[]{}—=+*^?#________"

        // Initial random text of same length as message
        const randomText = Array(finalText.length)
          .fill(0)
          .map(() => ({
            char: chars[Math.floor(Math.random() * chars.length)],
            revealed: false,
          }))

        // Set initial display text with all scrambled characters
        setDisplayText(JSON.stringify(randomText))

        // Gradually reveal the actual text
        const scramble = () => {
          if (!isHovered) return

          // Calculate how many characters to reveal in this iteration
          const progress = iteration / maxIterations
          const numToReveal = Math.floor(finalText.length * progress)

          // Create new text with some characters revealed and others scrambled
          const newText = finalText.split("").map((char, idx) => {
            // If this character should be revealed
            if (idx < numToReveal) {
              return {
                char: finalText[idx],
                revealed: true,
              }
            }
            // Otherwise show a random character
            return {
              char: chars[Math.floor(Math.random() * chars.length)],
              revealed: false,
            }
          })

          setDisplayText(JSON.stringify(newText))

          // Continue scrambling until all characters are revealed
          if (iteration < maxIterations) {
            iteration++
            animationTimeoutRef.current = setTimeout(scramble, 50)
          } else {
            // All characters revealed, set final text
            const finalTextObj = finalText.split("").map((char) => ({
              char,
              revealed: true,
            }))
            setDisplayText(JSON.stringify(finalTextObj))
            setIsAnimating(false)
          }
        }

        // Start the scramble animation after a delay to match the line extension
        animationTimeoutRef.current = setTimeout(scramble, 600)
      }

      startScramble()
    } else {
      // Reset when not hovered
      setDisplayText("")
      setIsAnimating(false)
    }

    // Clean up on unmount
    return () => {
      if (animationTimeoutRef.current) {
        clearTimeout(animationTimeoutRef.current)
      }
    }
  }, [isHovered, message])

  // Determine line and text positioning based on direction
  const getLineStyles = () => {
    switch (direction) {
      case "right":
        return {
          container: "absolute left-1/2 top-1/2 -translate-y-1/2 flex items-center",
          lineClass: `h-px transition-all duration-300 ease-out
          ${isHovered ? "w-16 opacity-100 delay-300" : "w-0 opacity-0"}`,
          lineStyle: {
            background: `linear-gradient(to right, rgba(${glowColor}, 0.7), rgba(255, 255, 255, 0.5))`,
          },
          text: `ml-2 text-xs text-white/90 whitespace-nowrap transition-all duration-300
          ${isHovered ? "opacity-100 translate-x-0 delay-500" : "opacity-0 -translate-x-4"}`,
        }
      case "left":
        return {
          container: "absolute right-1/2 top-1/2 -translate-y-1/2 flex items-center flex-row-reverse",
          lineClass: `h-px transition-all duration-300 ease-out
          ${isHovered ? "w-16 opacity-100 delay-300" : "w-0 opacity-0"}`,
          lineStyle: {
            background: `linear-gradient(to left, rgba(${glowColor}, 0.7), rgba(255, 255, 255, 0.5))`,
          },
          text: `mr-2 text-xs text-white/90 whitespace-nowrap transition-all duration-300
          ${isHovered ? "opacity-100 translate-x-0 delay-500" : "opacity-0 translate-x-4"}`,
        }
      case "top":
        return {
          container: "absolute left-1/2 bottom-1/2 -translate-x-1/2 flex flex-col items-center flex-col-reverse",
          lineClass: `w-px transition-all duration-300 ease-out
          ${isHovered ? "h-16 opacity-100 delay-300" : "h-0 opacity-0"}`,
          lineStyle: {
            background: `linear-gradient(to top, rgba(${glowColor}, 0.7), rgba(255, 255, 255, 0.5))`,
          },
          text: `mb-2 text-xs text-white/90 whitespace-nowrap transition-all duration-300
          ${isHovered ? "opacity-100 translate-y-0 delay-500" : "opacity-0 translate-y-4"}`,
        }
      case "bottom":
        return {
          container: "absolute left-1/2 top-1/2 -translate-x-1/2 flex flex-col items-center",
          lineClass: `w-px transition-all duration-300 ease-out
          ${isHovered ? "h-16 opacity-100 delay-300" : "h-0 opacity-0"}`,
          lineStyle: {
            background: `linear-gradient(to bottom, rgba(${glowColor}, 0.7), rgba(255, 255, 255, 0.5))`,
          },
          text: `mt-2 text-xs text-white/90 whitespace-nowrap transition-all duration-300
          ${isHovered ? "opacity-100 translate-y-0 delay-500" : "opacity-0 -translate-y-4"}`,
        }
      default:
        return {
          container: "absolute left-1/2 top-1/2 -translate-y-1/2 flex items-center",
          lineClass: `h-px transition-all duration-300 ease-out
          ${isHovered ? "w-16 opacity-100 delay-300" : "w-0 opacity-0"}`,
          lineStyle: {
            background: `linear-gradient(to right, rgba(${glowColor}, 0.7), rgba(255, 255, 255, 0.5))`,
          },
          text: `ml-2 text-xs text-white/90 whitespace-nowrap transition-all duration-300
          ${isHovered ? "opacity-100 translate-x-0 delay-500" : "opacity-0 -translate-x-4"}`,
        }
    }
  }

  const styles = getLineStyles()

  // Parse the display text from JSON
  const parsedDisplayText = displayText ? JSON.parse(displayText) : []

  // Create glow styles using inline style for better compatibility
  const outerGlowStyle = {
    boxShadow: isHovered ? `0 0 10px rgba(${glowColor}, 0.3)` : "none",
  }

  const innerGlowStyle = {
    boxShadow: isHovered ? `0 0 6px rgba(${glowColor}, 0.3)` : "none",
  }

  return (
    <div
      className="relative cursor-pointer"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {/* Inner dot */}
      <div className="h-1.5 w-1.5 rounded-full bg-white/80 transition-all duration-300" />

      {/* Outer circle */}
      <div
        className={`absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 rounded-full border border-white/30 transition-all duration-300 
          ${isHovered ? "h-8 w-8 opacity-100" : "h-0 w-0 opacity-0"}`}
        style={outerGlowStyle}
      />

      {/* Middle circle */}
      <div
        className={`absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 rounded-full border border-white/50 transition-all duration-300 
          ${isHovered ? "h-5 w-5 opacity-100 delay-75" : "h-0 w-0 opacity-0"}`}
        style={innerGlowStyle}
      />

      {/* Line and text container */}
      <div className={styles.container}>
        {/* Line */}
        <div className={styles.lineClass} style={styles.lineStyle} />

        {/* Text message with scramble effect */}
        <div className={styles.text}>
          <span className="font-mono">
            {isHovered && displayText ? (
              <>
                {parsedDisplayText.map((item: { char: string; revealed: boolean }, index: number) => (
                  <span
                    key={index}
                    className={`transition-opacity duration-100 ${item.revealed ? "text-white/90" : "text-white/40"}`}
                  >
                    {item.char}
                  </span>
                ))}
              </>
            ) : (
              " "
            )}
          </span>
        </div>
      </div>
    </div>
  )
}
